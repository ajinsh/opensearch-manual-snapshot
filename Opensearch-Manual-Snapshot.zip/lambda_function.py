import json
import urllib.parse
import boto3
from CustomSnapshot import CustomSnapshot



def lambda_handler(event, context):
	cs = CustomSnapshot('https://<ES-ENDPOINT>/','<CLUSTER-REGION>','es','<S3-BUCKET-NAME>','snapshot-')
	# print(cs.check_health())
	print(cs.list_snapshots())

	if len(cs.list_snapshots()) == 0:
		cs.register_repo()
	cs.delete_oldest_snapshot()
	cs.take_new_snapshot()
